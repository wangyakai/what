# Dianping-Source

《[大众点评](http://community.apicloud.com/bbs/forum.php?mod=viewthread&tid=580&extra=page%3D1)》

作者：ringking

描述：该分享在布局上算是o2o中常见的布局，大众到目前为止也一直在使用。其他布局以及参考点、参考方式与饿了么大致差不多，另外用到一些经典的模块如：scanner、speechRecognizer语音识别等。
